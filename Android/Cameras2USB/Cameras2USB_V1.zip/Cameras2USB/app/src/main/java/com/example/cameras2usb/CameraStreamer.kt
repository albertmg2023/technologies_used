package com.example.cameras2usb

import android.Manifest
import android.content.Context
import android.graphics.*
import android.hardware.camera2.*
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import androidx.annotation.RequiresPermission
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer

class CameraStreamer(
    private val context: Context,
    private val cameraIds: List<String>,  // AHORA recibimos lista de cámaras
    private val serverPort: Int
) {

    private val TAG = "CameraStreamer"
    private val cameras = mutableMapOf<String, CameraDevice>()
    private val captureSessions = mutableMapOf<String, CameraCaptureSession>()

    private var mediaCodec: MediaCodec? = null
    private var socket: Socket? = null
    private var outputStream: OutputStream? = null
    private var spsPpsData: ByteArray? = null

    private val cameraThread = HandlerThread("CameraThread").apply { start() }
    private val cameraHandler = Handler(cameraThread.looper)

    private val codecThread = HandlerThread("CodecThread").apply { start() }
    private val codecHandler = Handler(codecThread.looper)

    fun startStreaming() {
        Thread { waitForClient() }.start()
    }

    private fun waitForClient() {
        try {
            val serverSocket = ServerSocket(serverPort)
            Log.d(TAG, "Esperando cliente en puerto $serverPort")
            socket = serverSocket.accept()
            outputStream = socket?.getOutputStream()
            Log.d(TAG, "Cliente conectado en puerto $serverPort")
            openCameras()
        } catch (e: Exception) {
            Log.e(TAG, "Error en server: ${e.message}")
        }
    }

    @RequiresPermission(Manifest.permission.CAMERA)
    private fun openCameras() {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (cameraId in cameraIds) {
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameras[cameraId] = camera
                    if (cameras.size == cameraIds.size) {
                        setupMediaCodec()
                    }
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    Log.e(TAG, "Error abriendo cámara $cameraId: $error")
                    camera.close()
                }
            }, cameraHandler)
        }
    }

    private fun setupMediaCodec() {
        try {
            val width = 640 * cameraIds.size  // ancho combinado
            val height = 480                 // mismo alto

            val format = MediaFormat.createVideoFormat("video/avc", width, height)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            format.setInteger(MediaFormat.KEY_BIT_RATE, 800_000)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, 15)
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

            mediaCodec = MediaCodec.createEncoderByType("video/avc")
            mediaCodec?.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = mediaCodec!!.createInputSurface()
            mediaCodec?.start()

            // Creamos un CaptureRequest para cada cámara apuntando al mismo Surface
            for ((id, camera) in cameras) {
                camera.createCaptureSession(
                    listOf(inputSurface),
                    object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(session: CameraCaptureSession) {
                            captureSessions[id] = session
                            val requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                            requestBuilder.addTarget(inputSurface)
                            session.setRepeatingRequest(requestBuilder.build(), null, cameraHandler)
                            if (captureSessions.size == cameras.size) {
                                startCodecLoop()
                            }
                        }

                        override fun onConfigureFailed(session: CameraCaptureSession) {
                            Log.e(TAG, "Falló configuración de cámara $id")
                        }
                    }, cameraHandler
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error configurando MediaCodec: ${e.message}")
        }
    }

    private fun startCodecLoop() {
        codecHandler.post(object : Runnable {
            override fun run() {
                mediaCodec?.let { codec ->
                    val bufferInfo = MediaCodec.BufferInfo()
                    var outputBufferId = codec.dequeueOutputBuffer(bufferInfo, 0)

                    while (outputBufferId >= 0) {
                        val encodedData: ByteBuffer? = codec.getOutputBuffer(outputBufferId)
                        encodedData?.let { buffer ->
                            val flags = bufferInfo.flags
                            if (flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                                spsPpsData = ByteArray(bufferInfo.size)
                                buffer.get(spsPpsData)
                            } else {
                                val frameData = ByteArray(bufferInfo.size)
                                buffer.get(frameData)
                                val packet = if (flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0 && spsPpsData != null) {
                                    spsPpsData!! + frameData
                                } else {
                                    frameData
                                }
                                try {
                                    outputStream?.write(packet)
                                    outputStream?.flush()
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error enviando frame: ${e.message}")
                                    stopStreaming()
                                    return
                                }
                            }
                        }
                        codec.releaseOutputBuffer(outputBufferId, false)
                        outputBufferId = codec.dequeueOutputBuffer(bufferInfo, 0)
                    }

                    codecHandler.postDelayed(this, 10)
                }
            }
        })
    }

    fun stopStreaming() {
        try {
            captureSessions.values.forEach { it.close() }
            cameras.values.forEach { it.close() }
            mediaCodec?.stop()
            mediaCodec?.release()
            socket?.close()
            outputStream?.close()
            cameraThread.quitSafely()
            codecThread.quitSafely()
            Log.d(TAG, "Streaming detenido")
        } catch (e: Exception) {
            Log.e(TAG, "Error deteniendo streaming: ${e.message}")
        }
    }
}
