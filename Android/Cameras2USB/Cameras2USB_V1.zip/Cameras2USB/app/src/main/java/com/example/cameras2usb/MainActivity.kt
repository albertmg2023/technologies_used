package com.example.cameras2usb

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private var cameraStreamer: CameraStreamer? = null
    private val basePort = 5600

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
        }

        val startBtn = findViewById<Button>(R.id.startButton)
        val stopBtn = findViewById<Button>(R.id.stopButton)

        startBtn.setOnClickListener { startStreaming() }
        stopBtn.setOnClickListener { stopStreaming() }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Permiso de cámara concedido", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startStreaming() {
        if (cameraStreamer != null) {
            Toast.makeText(this, "Streaming ya iniciado", Toast.LENGTH_SHORT).show()
            return
        }

        val cameraIds = cameraManager.cameraIdList.take(2).toList()

        if (cameraIds.isEmpty()) {
            Toast.makeText(this, "No hay cámaras disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        cameraStreamer = CameraStreamer(
            context = this,
            cameraIds = cameraIds,  // enviamos lista de cámaras
            serverPort = basePort
        )

        cameraStreamer?.startStreaming()
        Toast.makeText(this, "Streaming iniciado para ${cameraIds.size} cámaras", Toast.LENGTH_SHORT).show()
    }

    private fun stopStreaming() {
        cameraStreamer?.stopStreaming()
        cameraStreamer = null
        Toast.makeText(this, "Streaming detenido", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopStreaming()
    }
}
